// api/checkout.js — Stripe Checkout Session Creator
// Creates a Stripe hosted payment page and returns the URL

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { plan, email, successUrl, cancelUrl } = req.body;

  if (!plan || !email) {
    return res.status(400).json({ error: 'Missing plan or email' });
  }

  // Map plan names to your Stripe Price IDs
  // Create these in Stripe Dashboard → Products → Add Product
  const STRIPE_PRICES = {
    pro:  process.env.STRIPE_PRICE_PRO,   // e.g. price_1ABC...
    team: process.env.STRIPE_PRICE_TEAM,  // e.g. price_1XYZ...
  };

  const priceId = STRIPE_PRICES[plan];
  if (!priceId) {
    return res.status(400).json({ error: `Unknown plan: ${plan}` });
  }

  try {
    // Dynamically import stripe (no need to install globally)
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
      apiVersion: '2023-10-16',
    });

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      customer_email: email,
      success_url: successUrl || `${process.env.APP_URL}/index.html?upgraded=1`,
      cancel_url: cancelUrl || `${process.env.APP_URL}/login.html?plan=${plan}`,
      metadata: { plan, email },
      subscription_data: {
        metadata: { plan, email },
        trial_period_days: 7, // 7-day free trial
      },
      allow_promotion_codes: true,
    });

    res.status(200).json({ url: session.url, sessionId: session.id });
  } catch (error) {
    console.error('Stripe error:', error);
    res.status(500).json({ error: error.message });
  }
}
