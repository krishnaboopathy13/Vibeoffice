// ═══════════════════════════════════════════════════════
// VibeOffice — Main Application Logic
// ═══════════════════════════════════════════════════════

// Uses Vercel serverless proxy — keeps API key safe on the server
const API_URL = '/api/claude';
const MODEL = 'claude-sonnet-4-20250514';

// ── STATE ──────────────────────────────────────────────
let currentApp = 'home';
let currentTitle = 'Untitled';
let aiPanelOpen = false;
let aiHistory = [];
let lastAIResponse = '';

// Spreadsheet state
const ROWS = 50, COLS = 26;
let sheetData = {};
let selectedCell = {r: 0, c: 0};

// Slides state
let slides = [];
let currentSlide = 0;

// Recent files
let recentFiles = JSON.parse(localStorage.getItem('co_recent') || '[]');

// ── INIT ───────────────────────────────────────────────
window.addEventListener('load', () => {
  initSheet();
  initSlides();
  renderRecent();
  renderToolbar();
  updateStatus();
  // Word count for doc
  document.getElementById('doc-editor').addEventListener('input', updateStatus);
});

// ── NAVIGATION ────────────────────────────────────────
function showHome() {
  currentApp = 'home';
  document.getElementById('home-screen').style.display = 'flex';
  document.querySelectorAll('#doc-view,#sheet-view,#slides-view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  updateStatus();
  renderToolbar();
}

function openApp(type) {
  currentApp = type;
  document.getElementById('home-screen').style.display = 'none';
  document.querySelectorAll('#doc-view,#sheet-view,#slides-view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById(type+'-view').classList.add('active');
  document.getElementById('nav-'+type).classList.add('active');
  renderToolbar();
  updateStatus();
  updateAIQuickActions();
  if(type === 'sheet') focusCell(0,0);
  if(type === 'slide') renderSlideThumbs();
}

function createNew(type) {
  closeModal('new-modal');
  const names = {doc:'Untitled Document', sheet:'Untitled Spreadsheet', slide:'Untitled Presentation'};
  currentTitle = names[type];
  if(type === 'doc') document.getElementById('doc-editor').innerHTML = '<p></p>';
  if(type === 'sheet') { sheetData = {}; renderSheet(); }
  if(type === 'slide') { slides = [createBlankSlide()]; currentSlide = 0; renderSlides(); }
  openApp(type);
  addRecent(type, currentTitle);
}

function showNewModal() { document.getElementById('new-modal').style.display = 'flex'; }
function closeModal(id) { document.getElementById(id).style.display = 'none'; }

function addRecent(type, name) {
  recentFiles = recentFiles.filter(f => f.name !== name);
  recentFiles.unshift({ type, name, date: new Date().toLocaleDateString() });
  if(recentFiles.length > 5) recentFiles.pop();
  localStorage.setItem('co_recent', JSON.stringify(recentFiles));
  renderRecent();
}

function renderRecent() {
  const el = document.getElementById('recent-list');
  if(!recentFiles.length) { el.innerHTML = '<div style="color:var(--text3);font-size:13px;padding:16px 0">No recent files. Create something new!</div>'; return; }
  const icons = {doc:'📝', sheet:'📊', slide:'🎨'};
  el.innerHTML = recentFiles.map(f => `
    <div class="recent-item" onclick="openApp('${f.type}')">
      <div class="recent-icon">${icons[f.type]}</div>
      <div class="recent-info">
        <div class="recent-name">${f.name}</div>
        <div class="recent-meta">${f.type.charAt(0).toUpperCase()+f.type.slice(1)} · ${f.date}</div>
      </div>
    </div>
  `).join('');
}

// ── TOOLBAR ───────────────────────────────────────────
function renderToolbar() {
  const tb = document.getElementById('toolbar');
  tb.innerHTML = '';

  // Title
  const titleInput = document.createElement('input');
  titleInput.className = 'doc-title-input';
  titleInput.value = currentApp === 'home' ? 'VibeOffice' : currentTitle;
  titleInput.placeholder = 'Untitled';
  titleInput.onchange = (e) => { currentTitle = e.target.value; };
  if(currentApp === 'home') titleInput.readOnly = true;
  tb.appendChild(titleInput);

  const div0 = document.createElement('div'); div0.className = 'tb-divider'; tb.appendChild(div0);

  if(currentApp === 'doc') {
    tb.innerHTML += `
      <div class="toolbar-group">
        <select class="tb-select" onchange="execFmt('formatBlock',this.value)" title="Style">
          <option value="p">Paragraph</option>
          <option value="h1">Heading 1</option>
          <option value="h2">Heading 2</option>
          <option value="h3">Heading 3</option>
        </select>
        <select class="tb-select" onchange="execFmt('fontSize',this.value)" title="Font size" style="width:64px">
          <option value="2">10</option><option value="3" selected>12</option>
          <option value="4">14</option><option value="5">18</option>
          <option value="6">24</option><option value="7">36</option>
        </select>
      </div>
      <div class="toolbar-group">
        <button class="tb-btn" onclick="execFmt('bold')" title="Bold"><b>B</b></button>
        <button class="tb-btn" onclick="execFmt('italic')" title="Italic"><i>I</i></button>
        <button class="tb-btn" onclick="execFmt('underline')" title="Underline"><u>U</u></button>
        <button class="tb-btn" onclick="execFmt('strikeThrough')" title="Strike">S̶</button>
      </div>
      <div class="toolbar-group">
        <button class="tb-btn" onclick="execFmt('justifyLeft')" title="Align Left">≡</button>
        <button class="tb-btn" onclick="execFmt('justifyCenter')" title="Center">≡</button>
        <button class="tb-btn" onclick="execFmt('justifyRight')" title="Right">≡</button>
      </div>
      <div class="toolbar-group">
        <button class="tb-btn" onclick="execFmt('insertUnorderedList')" title="Bullet List">• —</button>
        <button class="tb-btn" onclick="execFmt('insertOrderedList')" title="Numbered List">1.</button>
        <button class="tb-btn" onclick="insertTable()" title="Insert Table">⊞</button>
      </div>
      <div class="toolbar-group">
        <div class="color-row">
          ${['#1a1a2e','#6c63ff','#f87171','#34d399','#fbbf24','#38bdf8'].map(c =>
            `<div class="color-swatch" style="background:${c}" onclick="execFmt('foreColor','${c}')" title="Text Color: ${c}"></div>`
          ).join('')}
        </div>
      </div>
      <div class="toolbar-group">
        <button class="tb-btn" onclick="execFmt('undo')" title="Undo">↩</button>
        <button class="tb-btn" onclick="execFmt('redo')" title="Redo">↪</button>
      </div>
    `;
  }

  if(currentApp === 'sheet') {
    tb.innerHTML += `
      <div class="toolbar-group">
        <button class="tb-btn" onclick="sheetBold()" title="Bold"><b>B</b></button>
        <button class="tb-btn" onclick="sheetFormat('center')" title="Center">≡</button>
        <button class="tb-btn" onclick="addSheetRow()" title="Add Row">+Row</button>
        <button class="tb-btn wide" onclick="addSheetCol()" title="Add Column">+Col</button>
      </div>
      <div class="toolbar-group">
        <button class="tb-btn wide" onclick="insertSheetFormula('SUM')" title="Sum">Σ SUM</button>
        <button class="tb-btn wide" onclick="insertSheetFormula('AVERAGE')" title="Average">∅ AVG</button>
        <button class="tb-btn wide" onclick="insertSheetFormula('COUNT')" title="Count">Count</button>
      </div>
      <div class="toolbar-group">
        <div class="color-row">
          ${['#6c63ff','#f87171','#34d399','#fbbf24','#38bdf8'].map(c =>
            `<div class="color-swatch" style="background:${c}" onclick="setCellBg('${c}')" title="Cell Color"></div>`
          ).join('')}
        </div>
      </div>
    `;
  }

  if(currentApp === 'slide') {
    tb.innerHTML += `
      <div class="toolbar-group">
        <button class="tb-btn wide" onclick="addSlide()" title="Add Slide">+ Slide</button>
        <button class="tb-btn wide" onclick="deleteSlide()" title="Delete Slide">Del Slide</button>
      </div>
      <div class="toolbar-group">
        <button class="tb-btn wide" onclick="addSlideText()" title="Add Text">T Text</button>
        <button class="tb-btn wide" onclick="addSlideBox()" title="Add Box">□ Box</button>
      </div>
      <div class="toolbar-group">
        <select class="tb-select" onchange="setSlideTheme(this.value)" title="Theme">
          <option value="default">White</option>
          <option value="dark">Dark</option>
          <option value="ocean">Ocean</option>
          <option value="sunset">Sunset</option>
          <option value="forest">Forest</option>
        </select>
      </div>
    `;
  }

  // Rebuild title reference
  const newTitle = tb.querySelector('.doc-title-input');
  if(newTitle) {
    newTitle.value = currentApp === 'home' ? 'VibeOffice' : currentTitle;
    newTitle.onchange = (e) => { currentTitle = e.target.value; };
  }
}

function execFmt(cmd, val) {
  document.getElementById('doc-editor').focus();
  document.execCommand(cmd, false, val || null);
}

function insertTable() {
  const rows = 3, cols = 3;
  let html = '<table><thead><tr>' + Array(cols).fill('<th>Header</th>').join('') + '</tr></thead><tbody>';
  for(let r=0; r<rows; r++) html += '<tr>' + Array(cols).fill('<td>Cell</td>').join('') + '</tr>';
  html += '</tbody></table><p></p>';
  document.execCommand('insertHTML', false, html);
}

// ── STATUS BAR ────────────────────────────────────────
function updateStatus() {
  const modes = {home:'Home', doc:'Document', sheet:'Spreadsheet', slide:'Presentation'};
  document.getElementById('status-mode').textContent = 'Mode: ' + (modes[currentApp]||'Home');
  if(currentApp === 'doc') {
    const text = document.getElementById('doc-editor').innerText;
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    document.getElementById('status-words').textContent = `Words: ${words}`;
  } else {
    document.getElementById('status-words').textContent = '';
  }
}

// ══════════════════════════════════════════════════════
// SPREADSHEET ENGINE
// ══════════════════════════════════════════════════════
function cellId(r, c) { return String.fromCharCode(65+c) + (r+1); }

function initSheet() { renderSheet(); }

function renderSheet() {
  const grid = document.getElementById('sheet-grid');
  let html = '<table class="sheet-table"><thead><tr><th class="row-header"></th>';
  for(let c=0; c<COLS; c++) html += `<th>${String.fromCharCode(65+c)}</th>`;
  html += '</tr></thead><tbody>';
  for(let r=0; r<ROWS; r++) {
    html += `<tr><td class="row-num">${r+1}</td>`;
    for(let c=0; c<COLS; c++) {
      const id = cellId(r,c);
      const cell = sheetData[id] || {};
      const val = cell.display !== undefined ? cell.display : (cell.value || '');
      const style = cell.style || '';
      html += `<td id="td-${id}" onclick="selectCell(${r},${c})" ondblclick="editCell(${r},${c})">
        <input class="sheet-cell" id="cell-${id}" value="${escHtml(String(val))}"
          onfocus="selectCell(${r},${c})"
          onblur="commitCell(${r},${c},this.value)"
          onkeydown="cellKeydown(event,${r},${c})"
          style="${style}" readonly>
      </td>`;
    }
    html += '</tr>';
  }
  html += '</tbody></table>';
  grid.innerHTML = html;
}

function escHtml(s) { return s.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;'); }

function selectCell(r, c) {
  document.querySelectorAll('.sheet-table td.selected').forEach(el => el.classList.remove('selected'));
  selectedCell = {r, c};
  const id = cellId(r,c);
  const td = document.getElementById('td-'+id);
  if(td) td.classList.add('selected');
  document.getElementById('cell-ref').textContent = id;
  const cell = sheetData[id] || {};
  document.getElementById('formula-input').value = cell.formula || cell.value || '';
}

function editCell(r, c) {
  const id = cellId(r,c);
  const input = document.getElementById('cell-'+id);
  if(input) {
    input.removeAttribute('readonly');
    const cell = sheetData[id] || {};
    input.value = cell.formula || cell.value || '';
    input.focus();
  }
}

function commitCell(r, c, val) {
  const id = cellId(r,c);
  const input = document.getElementById('cell-'+id);
  if(input) input.setAttribute('readonly', true);
  if(val.startsWith('=')) {
    sheetData[id] = { formula: val, value: val, display: evalFormula(val) };
  } else {
    sheetData[id] = { value: val, display: val };
  }
  if(input) input.value = sheetData[id].display;
  document.getElementById('formula-input').value = val;
  updateStatus();
}

function applyFormula() {
  const val = document.getElementById('formula-input').value;
  const {r, c} = selectedCell;
  commitCell(r, c, val);
}

function cellKeydown(e, r, c) {
  if(e.key === 'Enter') { e.preventDefault(); commitCell(r,c,e.target.value); focusCell(r+1,c); }
  if(e.key === 'Tab') { e.preventDefault(); commitCell(r,c,e.target.value); focusCell(r,c+1); }
  if(e.key === 'Escape') { e.target.setAttribute('readonly',true); e.target.blur(); }
  if(e.key === 'ArrowUp' && e.target.getAttribute('readonly')) focusCell(r-1,c);
  if(e.key === 'ArrowDown' && e.target.getAttribute('readonly')) focusCell(r+1,c);
  if(e.key === 'ArrowLeft' && e.target.getAttribute('readonly')) focusCell(r,c-1);
  if(e.key === 'ArrowRight' && e.target.getAttribute('readonly')) focusCell(r,c+1);
}

function focusCell(r, c) {
  r = Math.max(0, Math.min(ROWS-1, r));
  c = Math.max(0, Math.min(COLS-1, c));
  selectCell(r, c);
  const id = cellId(r,c);
  const input = document.getElementById('cell-'+id);
  if(input) input.focus();
}

function evalFormula(formula) {
  try {
    const expr = formula.substring(1).toUpperCase();

    // SUM(range)
    const sumMatch = expr.match(/^SUM\(([A-Z]+\d+):([A-Z]+\d+)\)$/);
    if(sumMatch) return sumRange(sumMatch[1], sumMatch[2]);

    // AVERAGE
    const avgMatch = expr.match(/^AVERAGE\(([A-Z]+\d+):([A-Z]+\d+)\)$/);
    if(avgMatch) { const vals = rangeValues(avgMatch[1], avgMatch[2]); return vals.length ? (vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(2) : 0; }

    // COUNT
    const countMatch = expr.match(/^COUNT\(([A-Z]+\d+):([A-Z]+\d+)\)$/);
    if(countMatch) return rangeValues(countMatch[1], countMatch[2]).length;

    // MAX / MIN
    const maxMatch = expr.match(/^MAX\(([A-Z]+\d+):([A-Z]+\d+)\)$/);
    if(maxMatch) { const v = rangeValues(maxMatch[1], maxMatch[2]); return v.length ? Math.max(...v) : 0; }
    const minMatch = expr.match(/^MIN\(([A-Z]+\d+):([A-Z]+\d+)\)$/);
    if(minMatch) { const v = rangeValues(minMatch[1], minMatch[2]); return v.length ? Math.min(...v) : 0; }

    // Simple arithmetic with cell refs
    const evalExpr = expr.replace(/([A-Z]+\d+)/g, (ref) => {
      const cell = sheetData[ref];
      return cell ? (parseFloat(cell.display) || 0) : 0;
    });
    return Function('"use strict"; return (' + evalExpr + ')')();
  } catch(e) { return '#ERR'; }
}

function parseCellRef(ref) {
  const m = ref.match(/^([A-Z]+)(\d+)$/);
  if(!m) return null;
  const c = m[1].charCodeAt(0) - 65;
  const r = parseInt(m[2]) - 1;
  return {r, c};
}

function rangeValues(from, to) {
  const f = parseCellRef(from), t = parseCellRef(to);
  if(!f || !t) return [];
  const vals = [];
  for(let r=f.r; r<=t.r; r++) for(let c=f.c; c<=t.c; c++) {
    const id = cellId(r,c);
    const cell = sheetData[id];
    if(cell && cell.display !== '' && !isNaN(parseFloat(cell.display))) vals.push(parseFloat(cell.display));
  }
  return vals;
}

function sumRange(from, to) { return rangeValues(from, to).reduce((a,b)=>a+b,0); }

function insertSheetFormula(fn) {
  const {r, c} = selectedCell;
  const id = cellId(r,c);
  const input = document.getElementById('cell-'+id);
  if(input) {
    input.removeAttribute('readonly');
    input.value = `=${fn}(A1:A10)`;
    input.focus();
    document.getElementById('formula-input').value = input.value;
  }
}

function addSheetRow() { /* rows always available */ alert('Rows extend automatically as needed.'); }
function addSheetCol() { alert('Columns extend automatically as needed.'); }
function sheetBold() {
  const id = cellId(selectedCell.r, selectedCell.c);
  const cell = sheetData[id] || {};
  cell.style = (cell.style||'').includes('font-weight:bold') ? '' : 'font-weight:bold';
  sheetData[id] = cell;
  const input = document.getElementById('cell-'+id);
  if(input) input.style.fontWeight = cell.style.includes('bold') ? 'bold' : '';
}
function setCellBg(color) {
  const id = cellId(selectedCell.r, selectedCell.c);
  const cell = sheetData[id] || {};
  cell.style = (cell.style||'') + `background:${color};color:white;`;
  sheetData[id] = cell;
  const td = document.getElementById('td-'+id);
  if(td) td.style.background = color;
}
function sheetFormat(align) {
  const id = cellId(selectedCell.r, selectedCell.c);
  const input = document.getElementById('cell-'+id);
  if(input) input.style.textAlign = align;
}

// ══════════════════════════════════════════════════════
// PRESENTATION ENGINE
// ══════════════════════════════════════════════════════
function createBlankSlide(theme='default') {
  return {
    theme,
    bg: null,
    elements: [
      { type:'text', role:'title', content:'Click to add title', x:10, y:30, w:80, fontSize:36, bold:true, color:'#1a1a2e', align:'center' },
      { type:'text', role:'subtitle', content:'Click to add subtitle', x:10, y:60, w:80, fontSize:18, bold:false, color:'#555', align:'center' }
    ]
  };
}

function initSlides() {
  slides = [createBlankSlide()];
  currentSlide = 0;
}

function renderSlides() {
  renderSlideThumbs();
  renderCurrentSlide();
}

function renderSlideThumbs() {
  const container = document.getElementById('slide-thumbs');
  container.innerHTML = slides.map((sl, i) => `
    <div class="slide-thumb ${i===currentSlide?'active':''} slide-theme-${sl.theme}" onclick="goToSlide(${i})">
      ${sl.elements.map(el => el.role==='title' ? `<div style="font-size:6px;text-align:center;padding:4px;color:${getElColor(el,sl.theme)};font-weight:bold;overflow:hidden;max-height:30px">${el.content}</div>` : '').join('')}
      <div class="slide-thumb-num">${i+1}</div>
    </div>
  `).join('');
}

function getElColor(el, theme) {
  if(theme === 'dark' || theme === 'ocean' || theme === 'sunset' || theme === 'forest') return '#fff';
  return el.color || '#1a1a2e';
}

function goToSlide(i) {
  currentSlide = i;
  renderSlideThumbs();
  renderCurrentSlide();
}

function renderCurrentSlide() {
  const canvas = document.getElementById('slide-canvas');
  if(!canvas || !slides[currentSlide]) return;
  const sl = slides[currentSlide];
  const themes = {
    default: 'background:white',
    dark: 'background:#1a1a2e',
    ocean: 'background:linear-gradient(135deg,#0f2027,#203a43,#2c5364)',
    sunset: 'background:linear-gradient(135deg,#f093fb,#f5576c)',
    forest: 'background:linear-gradient(135deg,#134e5e,#71b280)'
  };
  canvas.style.cssText = themes[sl.theme] || themes.default;
  canvas.innerHTML = sl.elements.map((el, ei) => {
    const isLight = ['dark','ocean','sunset','forest'].includes(sl.theme);
    const color = isLight ? 'white' : (el.color || '#1a1a2e');
    if(el.type === 'text') return `
      <div class="slide-element slide-text-el" style="left:${el.x}%;top:${el.y}%;width:${el.w}%;font-size:${el.fontSize}px;font-weight:${el.bold?'bold':'normal'};color:${color};text-align:${el.align||'left'}" 
        contenteditable="true" onblur="saveSlideEl(${ei},this.innerText)"
        onclick="this.focus()">${el.content}</div>
    `;
    if(el.type === 'box') return `
      <div class="slide-element" style="left:${el.x}%;top:${el.y}%;width:${el.w||20}%;height:${el.h||15}%;background:${el.bg||'rgba(108,99,255,0.3)'};border-radius:8px;border:2px solid rgba(108,99,255,0.5)"></div>
    `;
    return '';
  }).join('');
}

function saveSlideEl(ei, text) {
  if(slides[currentSlide]) slides[currentSlide].elements[ei].content = text;
  renderSlideThumbs();
}

function addSlide() {
  const theme = slides[currentSlide] ? slides[currentSlide].theme : 'default';
  slides.splice(currentSlide+1, 0, createBlankSlide(theme));
  currentSlide++;
  renderSlides();
}

function deleteSlide() {
  if(slides.length <= 1) return;
  slides.splice(currentSlide, 1);
  currentSlide = Math.min(currentSlide, slides.length-1);
  renderSlides();
}

function addSlideText() {
  slides[currentSlide].elements.push({ type:'text', content:'New text', x:10, y:40, w:80, fontSize:18, bold:false, color:'#333', align:'left' });
  renderCurrentSlide();
}

function addSlideBox() {
  slides[currentSlide].elements.push({ type:'box', x:20, y:20, w:30, h:20, bg:'rgba(108,99,255,0.25)' });
  renderCurrentSlide();
}

function setSlideTheme(theme) {
  if(slides[currentSlide]) {
    slides[currentSlide].theme = theme;
    renderSlides();
  }
}

// ══════════════════════════════════════════════════════
// AI PANEL
// ══════════════════════════════════════════════════════
function toggleAI() {
  aiPanelOpen = !aiPanelOpen;
  const panel = document.getElementById('ai-panel');
  panel.classList.toggle('collapsed', !aiPanelOpen);
  if(aiPanelOpen) {
    updateAIQuickActions();
    setTimeout(() => document.getElementById('ai-input').focus(), 300);
  }
}

function updateAIQuickActions() {
  const qa = document.getElementById('ai-quick-actions');
  const actions = {
    doc: ['✍️ Write intro', '📝 Summarize', '💡 Improve text', '🔤 Fix grammar', '📋 Make bullet points', '📄 Draft email'],
    sheet: ['📊 Analyze data', '🧮 Suggest formulas', '📈 Data insights', '🔍 Find patterns', '📋 Create table data'],
    slide: ['🎨 Generate slide content', '📌 Suggest structure', '✨ Improve title', '📊 Add data slide', '🗣️ Speaker notes'],
    home: ['💡 What can you do?', '📝 Start a document', '📊 Create spreadsheet']
  };
  const btns = (actions[currentApp] || actions.home).map(a =>
    `<button class="ai-qa-btn" onclick="quickAction('${a}')">${a}</button>`
  ).join('');
  qa.innerHTML = btns;
}

function quickAction(action) {
  const clean = action.replace(/^[\u{1F300}-\u{1FFFF}\u{2600}-\u{27FF}]+\s*/gu, '').trim();
  document.getElementById('ai-input').value = clean;
  sendAI();
}

function aiKeydown(e) {
  if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendAI(); }
}

function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 100) + 'px';
}

async function sendAI() {
  const input = document.getElementById('ai-input');
  const msg = input.value.trim();
  if(!msg) return;
  input.value = '';
  input.style.height = 'auto';

  appendAIMsg('user', msg);
  const typingEl = appendTyping();

  // Build context
  let ctx = '';
  if(currentApp === 'doc') {
    const text = document.getElementById('doc-editor').innerText;
    ctx = text ? `\n\nCurrent document content:\n${text.substring(0,2000)}` : '';
  }
  if(currentApp === 'sheet') {
    const cells = Object.entries(sheetData).filter(([,v])=>v.value).slice(0,30);
    ctx = cells.length ? `\n\nSpreadsheet data: ${cells.map(([k,v])=>k+':'+v.display).join(', ')}` : '';
  }
  if(currentApp === 'slide') {
    const sl = slides[currentSlide];
    ctx = sl ? `\n\nCurrent slide (${currentSlide+1} of ${slides.length}): ${JSON.stringify(sl.elements.map(e=>({role:e.role,content:e.content})))}` : '';
  }

  const appCtx = {
    doc: 'You are an AI assistant integrated into a word processor. Help with writing, editing, and formatting documents.',
    sheet: 'You are an AI assistant integrated into a spreadsheet application. Help with formulas, data analysis, and insights.',
    slide: 'You are an AI assistant integrated into a presentation tool. Help with slide content, structure, and design.',
    home: 'You are Claude, an AI assistant integrated into VibeOffice — a web-based office suite.'
  };

  const systemPrompt = `${appCtx[currentApp]||appCtx.home} When you generate content that should be inserted into the document, wrap it in <INSERT> tags. Keep responses concise and actionable.${ctx}`;

  aiHistory.push({ role: 'user', content: msg });

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1000,
        system: systemPrompt,
        messages: aiHistory.slice(-10)
      })
    });
    const data = await response.json();
    const reply = data.content?.[0]?.text || 'Sorry, I could not generate a response.';

    typingEl.remove();
    lastAIResponse = reply;
    aiHistory.push({ role: 'assistant', content: reply });

    const hasInsert = reply.includes('<INSERT>');
    const displayReply = reply.replace(/<INSERT>([\s\S]*?)<\/INSERT>/g, (_, content) => {
      return `\n\n📋 *Content ready to insert:*\n${content.trim()}`;
    });

    appendAIMsg('assistant', displayReply, hasInsert);
  } catch(e) {
    typingEl.remove();
    appendAIMsg('assistant', '⚠️ Could not connect to Claude API. Please check your connection.');
  }
}

function appendAIMsg(role, text, showInsert=false) {
  const container = document.getElementById('ai-messages');
  const avatar = role === 'user' ? '👤' : '✦';
  const div = document.createElement('div');
  div.className = `ai-msg ${role} fade-in`;

  // Simple markdown-like rendering
  let html = text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    .replace(/`(.*?)`/g, '<code>$1</code>')
    .replace(/\n/g, '<br>');

  div.innerHTML = `
    <div class="ai-msg-avatar">${avatar}</div>
    <div class="ai-msg-bubble">
      ${html}
      ${showInsert ? `<button class="ai-insert-btn" onclick="insertAIContent()">⬇ Insert into document</button>` : ''}
    </div>
  `;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  return div;
}

function appendTyping() {
  const container = document.getElementById('ai-messages');
  const div = document.createElement('div');
  div.className = 'ai-msg assistant';
  div.innerHTML = `<div class="ai-msg-avatar">✦</div><div class="ai-typing"><span></span><span></span><span></span></div>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
  return div;
}

function insertAIContent() {
  if(!lastAIResponse) return;
  // Extract content between INSERT tags or use full response
  const match = lastAIResponse.match(/<INSERT>([\s\S]*?)<\/INSERT>/);
  const content = match ? match[1].trim() : lastAIResponse.replace(/<[^>]+>/g, '').trim();

  if(currentApp === 'doc') {
    const editor = document.getElementById('doc-editor');
    editor.focus();
    const html = content.replace(/\n/g, '<br>');
    document.execCommand('insertHTML', false, html);
    appendAIMsg('assistant', '✅ Content inserted into your document!');
  } else if(currentApp === 'slide') {
    if(slides[currentSlide]) {
      slides[currentSlide].elements[0].content = content.split('\n')[0] || content;
      if(slides[currentSlide].elements[1]) slides[currentSlide].elements[1].content = content.split('\n')[1] || '';
      renderSlides();
      appendAIMsg('assistant', '✅ Content inserted into the current slide!');
    }
  } else if(currentApp === 'sheet') {
    const lines = content.split('\n').filter(l=>l.trim());
    lines.forEach((line, i) => {
      const parts = line.split(/[,\t]/);
      parts.forEach((val, j) => {
        const id = cellId(i, j);
        sheetData[id] = { value: val.trim(), display: val.trim() };
        const input = document.getElementById('cell-'+id);
        if(input) input.value = val.trim();
      });
    });
    appendAIMsg('assistant', '✅ Data inserted into your spreadsheet!');
  }
}

// ══════════════════════════════════════════════════════
// EXPORT FUNCTIONS
// ══════════════════════════════════════════════════════
function showExport() {
  const modal = document.getElementById('export-modal');
  const desc = document.getElementById('export-modal-desc');
  const opts = document.getElementById('export-options');

  if(currentApp === 'home') {
    desc.textContent = 'Please open a document first.';
    opts.innerHTML = '';
    modal.style.display = 'flex';
    return;
  }

  const exportOptions = {
    doc: [
      { label:'📄 Word Document (.docx)', fn:'exportDocx', color:'var(--doc)' },
      { label:'📃 HTML File (.html)', fn:'exportHTML', color:'var(--accent3)' },
      { label:'📋 Plain Text (.txt)', fn:'exportTxt', color:'var(--text2)' }
    ],
    sheet: [
      { label:'📊 Excel Spreadsheet (.xlsx)', fn:'exportXlsx', color:'var(--sheet)' },
      { label:'📋 CSV File (.csv)', fn:'exportCSV', color:'var(--accent3)' }
    ],
    slide: [
      { label:'🖼️ PowerPoint (.pptx)', fn:'exportPptx', color:'var(--slide)' },
      { label:'📄 HTML Presentation', fn:'exportSlideHTML', color:'var(--accent3)' }
    ]
  };

  desc.textContent = `Export "${currentTitle}"`;
  opts.innerHTML = exportOptions[currentApp].map(o =>
    `<button class="btn" style="width:100%;margin-bottom:8px;text-align:left;background:var(--surface);color:var(--text);border:1px solid var(--border);padding:12px 16px;border-radius:8px;cursor:pointer;font-family:var(--font-body)" 
      onmouseenter="this.style.borderColor='${o.color}'"
      onmouseleave="this.style.borderColor='var(--border)'"
      onclick="${o.fn}();closeModal('export-modal')">${o.label}</button>`
  ).join('');
  modal.style.display = 'flex';
}

// ── DOCX Export (client-side via XML) ────────────────
async function exportDocx() {
  const content = document.getElementById('doc-editor').innerHTML;
  const text = document.getElementById('doc-editor').innerText;

  // Build simple OOXML document
  const docXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:body>
${text.split('\n').filter(l=>l.trim()).map(line =>
  `<w:p><w:r><w:t xml:space="preserve">${line.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</w:t></w:r></w:p>`
).join('\n')}
<w:sectPr><w:pgSz w:w="12240" w:h="15840"/></w:sectPr>
</w:body></w:document>`;

  const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const wordRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`;

  const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr><w:sz w:val="24"/><w:szCs w:val="24"/></w:rPr></w:rPrDefault></w:docDefaults>
</w:styles>`;

  try {
    // Use JSZip if available, otherwise show instructions
    const zip = await createZip({
      '_rels/.rels': rels,
      'word/document.xml': docXml,
      'word/_rels/document.xml.rels': wordRels,
      'word/styles.xml': stylesXml,
      '[Content_Types].xml': contentTypes
    });
    downloadBlob(zip, currentTitle+'.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
  } catch(e) {
    exportHTML(); // fallback
  }
}

async function createZip(files) {
  // Minimal zip creator
  const encoder = new TextEncoder();
  const fileData = [];
  let offset = 0;
  const localHeaders = [];
  const centralDir = [];

  for(const [name, content] of Object.entries(files)) {
    const nameBytes = encoder.encode(name);
    const contentBytes = encoder.encode(content);
    const crc = crc32(contentBytes);
    const localHeader = buildLocalHeader(nameBytes, contentBytes, crc);
    localHeaders.push({ name, data: concatBytes([localHeader, contentBytes]), size: contentBytes.length, crc, nameBytes, offset });
    offset += localHeader.length + contentBytes.length;
  }

  const cdirStart = offset;
  for(const f of localHeaders) {
    centralDir.push(buildCentralDir(f.nameBytes, f.size, f.crc, f.offset));
  }

  const eocd = buildEOCD(localHeaders.length, centralDir.reduce((a,b)=>a+b.length,0), cdirStart);

  const parts = [...localHeaders.map(f=>f.data), ...centralDir, eocd];
  return new Blob([concatBytes(parts)], { type: 'application/zip' });
}

function concatBytes(arrays) {
  const total = arrays.reduce((n, a) => n + a.length, 0);
  const result = new Uint8Array(total);
  let offset = 0;
  for(const arr of arrays) { result.set(arr, offset); offset += arr.length; }
  return result;
}

function buildLocalHeader(name, data, crc) {
  const h = new Uint8Array(30 + name.length);
  const view = new DataView(h.buffer);
  view.setUint32(0, 0x04034b50, true); // signature
  view.setUint16(4, 20, true); // version
  view.setUint16(6, 0, true); // flags
  view.setUint16(8, 0, true); // no compression
  view.setUint16(10, 0, true); // mod time
  view.setUint16(12, 0, true); // mod date
  view.setUint32(14, crc, true);
  view.setUint32(18, data.length, true);
  view.setUint32(22, data.length, true);
  view.setUint16(26, name.length, true);
  view.setUint16(28, 0, true);
  h.set(name, 30);
  return h;
}

function buildCentralDir(name, size, crc, offset) {
  const h = new Uint8Array(46 + name.length);
  const view = new DataView(h.buffer);
  view.setUint32(0, 0x02014b50, true);
  view.setUint16(4, 20, true); view.setUint16(6, 20, true);
  view.setUint16(8, 0, true); view.setUint16(10, 0, true);
  view.setUint16(12, 0, true); view.setUint16(14, 0, true);
  view.setUint32(16, crc, true);
  view.setUint32(20, size, true); view.setUint32(24, size, true);
  view.setUint16(28, name.length, true);
  view.setUint16(30, 0, true); view.setUint16(32, 0, true);
  view.setUint16(34, 0, true); view.setUint16(36, 0, true);
  view.setUint32(38, 0, true);
  view.setUint32(42, offset, true);
  h.set(name, 46);
  return h;
}

function buildEOCD(count, cdirSize, cdirOffset) {
  const h = new Uint8Array(22);
  const view = new DataView(h.buffer);
  view.setUint32(0, 0x06054b50, true);
  view.setUint16(4, 0, true); view.setUint16(6, 0, true);
  view.setUint16(8, count, true); view.setUint16(10, count, true);
  view.setUint32(12, cdirSize, true);
  view.setUint32(16, cdirOffset, true);
  view.setUint16(20, 0, true);
  return h;
}

function crc32(data) {
  let crc = 0xFFFFFFFF;
  const table = crc32Table();
  for(let i=0; i<data.length; i++) crc = (crc >>> 8) ^ table[(crc ^ data[i]) & 0xFF];
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function crc32Table() {
  const t = new Uint32Array(256);
  for(let i=0; i<256; i++) {
    let c = i;
    for(let j=0; j<8; j++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    t[i] = c;
  }
  return t;
}

// ── XLSX Export ───────────────────────────────────────
function exportXlsx() {
  const ws_data = [];
  for(let r=0; r<ROWS; r++) {
    const row = [];
    for(let c=0; c<COLS; c++) {
      const id = cellId(r,c);
      const cell = sheetData[id];
      const val = cell ? cell.display : '';
      row.push(val);
    }
    // Only add non-empty rows
    if(row.some(v=>v)) ws_data.push(row);
    else if(ws_data.length > 0 && r < 5) ws_data.push(row); // keep some empty rows at top
  }

  if(!ws_data.length) {
    ws_data.push(['No data']);
  }

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(ws_data);
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, currentTitle + '.xlsx');
}

// ── CSV Export ────────────────────────────────────────
function exportCSV() {
  const rows = [];
  for(let r=0; r<ROWS; r++) {
    const row = [];
    let hasData = false;
    for(let c=0; c<COLS; c++) {
      const id = cellId(r,c);
      const cell = sheetData[id];
      const val = cell ? cell.display : '';
      if(val) hasData = true;
      row.push(`"${val.replace(/"/g,'""')}"`);
    }
    if(hasData) rows.push(row.join(','));
  }
  downloadText(rows.join('\n'), currentTitle+'.csv', 'text/csv');
}

// ── HTML Export ───────────────────────────────────────
function exportHTML() {
  const content = document.getElementById('doc-editor').innerHTML;
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${currentTitle}</title>
<style>body{max-width:760px;margin:60px auto;font-family:Georgia,serif;font-size:14px;line-height:1.8;color:#1a1a2e}
h1{font-size:28px}h2{font-size:22px}h3{font-size:17px}table{border-collapse:collapse;width:100%}
td,th{border:1px solid #ccc;padding:8px 12px}th{background:#f0f0f0}</style>
</head><body><h1>${currentTitle}</h1>${content}</body></html>`;
  downloadText(html, currentTitle+'.html', 'text/html');
}

// ── TXT Export ────────────────────────────────────────
function exportTxt() {
  const text = document.getElementById('doc-editor').innerText;
  downloadText(text, currentTitle+'.txt', 'text/plain');
}

// ── PPTX Export ───────────────────────────────────────
async function exportPptx() {
  // Build minimal PPTX structure as a ZIP
  const slideXmls = slides.map((sl, i) => buildSlideXml(sl, i));
  const files = {
    '_rels/.rels': buildPptxRels(slides.length),
    '[Content_Types].xml': buildPptxContentTypes(slides.length),
    'ppt/presentation.xml': buildPresentationXml(slides.length),
    'ppt/_rels/presentation.xml.rels': buildPresRels(slides.length),
    'ppt/theme/theme1.xml': buildThemeXml(),
  };
  slides.forEach((sl, i) => {
    files[`ppt/slides/slide${i+1}.xml`] = slideXmls[i];
    files[`ppt/slides/_rels/slide${i+1}.xml.rels`] = buildSlideRels();
  });

  try {
    const zip = await createZip(files);
    downloadBlob(zip, currentTitle+'.pptx', 'application/vnd.openxmlformats-officedocument.presentationml.presentation');
  } catch(e) {
    exportSlideHTML();
  }
}

function buildSlideXml(sl, idx) {
  const themeColors = {
    default: { bg: 'FFFFFF', text: '1A1A2E' },
    dark:    { bg: '1A1A2E', text: 'FFFFFF' },
    ocean:   { bg: '0F2027', text: 'FFFFFF' },
    sunset:  { bg: 'F093FB', text: 'FFFFFF' },
    forest:  { bg: '134E5E', text: 'FFFFFF' }
  };
  const theme = themeColors[sl.theme] || themeColors.default;
  const titleEl = sl.elements.find(e => e.role === 'title');
  const subtitleEl = sl.elements.find(e => e.role === 'subtitle');
  const title = titleEl ? titleEl.content.replace(/&/g,'&amp;').replace(/</g,'&lt;') : 'Slide';
  const subtitle = subtitleEl ? subtitleEl.content.replace(/&/g,'&amp;').replace(/</g,'&lt;') : '';

  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
  xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="${theme.bg}"/></a:solidFill></p:bgPr></p:bg>
<p:spTree>
<p:sp><p:nvSpPr><p:cNvPr id="1" name="Title"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="title"/></p:nvPr></p:nvSpPr>
<p:spPr><a:xfrm><a:off x="457200" y="274638"/><a:ext cx="8229600" cy="1143000"/></a:xfrm></p:spPr>
<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" sz="3600" b="1"><a:solidFill><a:srgbClr val="${theme.text}"/></a:solidFill></a:rPr><a:t>${title}</a:t></a:r></a:p></p:txBody>
</p:sp>
<p:sp><p:nvSpPr><p:cNvPr id="2" name="Subtitle"/><p:cNvSpPr><a:spLocks noGrp="1"/></p:cNvSpPr><p:nvPr><p:ph type="subTitle" idx="1"/></p:nvPr></p:nvSpPr>
<p:spPr><a:xfrm><a:off x="457200" y="1600200"/><a:ext cx="8229600" cy="900000"/></a:xfrm></p:spPr>
<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:r><a:rPr lang="en-US" sz="1800"><a:solidFill><a:srgbClr val="${theme.text}"/></a:solidFill></a:rPr><a:t>${subtitle}</a:t></a:r></a:p></p:txBody>
</p:sp>
</p:spTree></p:cSld></p:sld>`;
}

function buildPptxRels(n) {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>
</Relationships>`;
}

function buildPptxContentTypes(n) {
  const slides = Array.from({length:n},(_,i)=>
    `<Override PartName="/ppt/slides/slide${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`
  ).join('\n');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>
<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
${slides}
</Types>`;
}

function buildPresentationXml(n) {
  const sldIds = Array.from({length:n},(_,i)=>
    `<p:sldId id="${i+256}" r:id="rId${i+1}"/>`
  ).join('\n');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
  xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">
<p:sldMasterIdLst/><p:sldSz cx="9144000" cy="5143500"/><p:notesSz cx="6858000" cy="9144000"/>
<p:sldIdLst>${sldIds}</p:sldIdLst>
</p:presentation>`;
}

function buildPresRels(n) {
  const rels = Array.from({length:n},(_,i)=>
    `<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i+1}.xml"/>`
  ).join('\n');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
${rels}
<Relationship Id="rId${n+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>
</Relationships>`;
}

function buildSlideRels() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>`;
}

function buildThemeXml() {
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme">
<a:themeElements><a:clrScheme name="Office">
<a:dk1><a:sysClr lastClr="000000" val="windowText"/></a:dk1>
<a:lt1><a:sysClr lastClr="FFFFFF" val="window"/></a:lt1>
<a:dk2><a:srgbClr val="1F497D"/></a:dk2>
<a:lt2><a:srgbClr val="EEECE1"/></a:lt2>
<a:accent1><a:srgbClr val="6C63FF"/></a:accent1>
<a:accent2><a:srgbClr val="ED7D31"/></a:accent2>
<a:accent3><a:srgbClr val="A9D18E"/></a:accent3>
<a:accent4><a:srgbClr val="4472C4"/></a:accent4>
<a:accent5><a:srgbClr val="ED7D31"/></a:accent5>
<a:accent6><a:srgbClr val="70AD47"/></a:accent6>
<a:hlink><a:srgbClr val="0563C1"/></a:hlink>
<a:folHlink><a:srgbClr val="954F72"/></a:folHlink>
</a:clrScheme>
<a:fontScheme name="Office"><a:majorFont><a:latin typeface="Calibri Light"/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/></a:minorFont></a:fontScheme>
<a:fmtScheme name="Office"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme>
</a:themeElements></a:theme>`;
}

function exportSlideHTML() {
  const slidesHtml = slides.map((sl, i) => {
    const themes = {
      default: 'background:white;color:#1a1a2e',
      dark: 'background:#1a1a2e;color:white',
      ocean: 'background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);color:white',
      sunset: 'background:linear-gradient(135deg,#f093fb,#f5576c);color:white',
      forest: 'background:linear-gradient(135deg,#134e5e,#71b280);color:white'
    };
    const title = sl.elements.find(e=>e.role==='title');
    const sub = sl.elements.find(e=>e.role==='subtitle');
    return `<div class="slide" style="${themes[sl.theme]||themes.default}">
      <div class="slide-num">${i+1}/${slides.length}</div>
      ${title?`<h1>${title.content}</h1>`:''}
      ${sub?`<p class="sub">${sub.content}</p>`:''}
    </div>`;
  }).join('');

  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${currentTitle}</title>
<style>
body{margin:0;background:#111;display:flex;flex-direction:column;align-items:center;padding:40px;gap:24px;font-family:Georgia,serif}
.slide{width:800px;height:450px;border-radius:12px;display:flex;flex-direction:column;align-items:center;justify-content:center;position:relative;box-shadow:0 8px 32px rgba(0,0,0,0.5);padding:48px}
h1{font-size:48px;font-weight:700;text-align:center;margin:0 0 16px}
.sub{font-size:22px;text-align:center;opacity:0.75;margin:0}
.slide-num{position:absolute;bottom:16px;right:20px;font-size:12px;opacity:0.5}
</style></head><body>${slidesHtml}</body></html>`;
  downloadText(html, currentTitle+'.html', 'text/html');
}

// ── Download helpers ──────────────────────────────────
function downloadText(content, filename, type) {
  const blob = new Blob([content], { type });
  downloadBlob(blob, filename, type);
}

function downloadBlob(blob, filename, type) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// ══════════════════════════════════════════════════════
// IMPORT ENGINE
// ══════════════════════════════════════════════════════

let importFileReady = null; // stores { file, type, appType }

const IMPORT_TYPES = {
  'txt':  { label:'Plain Text',     icon:'📄', app:'doc'   },
  'md':   { label:'Markdown',       icon:'📝', app:'doc'   },
  'html': { label:'HTML Document',  icon:'🌐', app:'doc'   },
  'htm':  { label:'HTML Document',  icon:'🌐', app:'doc'   },
  'docx': { label:'Word Document',  icon:'📘', app:'doc'   },
  'xlsx': { label:'Excel Sheet',    icon:'📗', app:'sheet' },
  'xls':  { label:'Excel Sheet',    icon:'📗', app:'sheet' },
  'csv':  { label:'CSV File',       icon:'📊', app:'sheet' },
  'pptx': { label:'PowerPoint',     icon:'📙', app:'slide' },
  'json': { label:'JSON Data',      icon:'🗂️', app:'sheet' },
};

const APP_COLORS = { doc:'var(--doc)', sheet:'var(--sheet)', slide:'var(--slide)' };
const APP_LABELS = { doc:'Document', sheet:'Spreadsheet', slide:'Presentation' };

function showImport() {
  importFileReady = null;
  // Reset UI
  const dz = document.getElementById('import-dropzone');
  dz.style.borderColor = 'var(--border)';
  dz.style.background = 'transparent';
  document.getElementById('import-status').style.display = 'none';
  document.getElementById('import-confirm-btn').style.display = 'none';
  document.getElementById('import-file-input').value = '';
  document.getElementById('import-modal').style.display = 'flex';
}

function importDragOver(e) {
  e.preventDefault();
  const dz = document.getElementById('import-dropzone');
  dz.style.borderColor = 'var(--accent)';
  dz.style.background = 'rgba(108,99,255,0.06)';
}

function importDragLeave(e) {
  const dz = document.getElementById('import-dropzone');
  dz.style.borderColor = 'var(--border)';
  dz.style.background = 'transparent';
}

function importDrop(e) {
  e.preventDefault();
  importDragLeave(e);
  const file = e.dataTransfer?.files?.[0];
  if(file) handleImportFile(file);
}

function handleImportFile(file) {
  if(!file) return;
  const ext = file.name.split('.').pop().toLowerCase();
  const meta = IMPORT_TYPES[ext];

  const dz = document.getElementById('import-dropzone');
  const status = document.getElementById('import-status');
  const confirmBtn = document.getElementById('import-confirm-btn');

  if(!meta) {
    dz.style.borderColor = 'var(--red)';
    dz.style.background = 'rgba(248,113,113,0.06)';
    document.getElementById('import-status').style.display = 'flex';
    document.getElementById('import-status-icon').textContent = '⚠️';
    document.getElementById('import-status-text').textContent = `Unsupported file type: .${ext}`;
    document.getElementById('import-status-badge').textContent = '';
    confirmBtn.style.display = 'none';
    importFileReady = null;
    return;
  }

  // Show success state
  dz.style.borderColor = APP_COLORS[meta.app];
  dz.style.background = `rgba(108,99,255,0.05)`;
  status.style.display = 'flex';
  document.getElementById('import-status-icon').textContent = meta.icon;
  document.getElementById('import-status-text').textContent = `${file.name} · ${(file.size/1024).toFixed(1)} KB`;
  const badge = document.getElementById('import-status-badge');
  badge.textContent = `→ Opens as ${APP_LABELS[meta.app]}`;
  badge.style.background = `rgba(108,99,255,0.15)`;
  badge.style.color = APP_COLORS[meta.app];
  confirmBtn.style.display = 'inline-flex';

  importFileReady = { file, ext, appType: meta.app, label: meta.label };
}

async function confirmImport() {
  if(!importFileReady) return;
  closeModal('import-modal');
  const { file, ext, appType } = importFileReady;
  currentTitle = file.name.replace(/\.[^.]+$/, '');

  try {
    if(appType === 'doc') await importDoc(file, ext);
    else if(appType === 'sheet') await importSheet(file, ext);
    else if(appType === 'slide') await importSlide(file, ext);
    addRecent(appType, currentTitle);
    openApp(appType);
    appendAIMsg('assistant', `✅ Imported **${file.name}** successfully! I can help you edit, summarize, or improve this content — just ask.`);
    if(!aiPanelOpen) toggleAI();
  } catch(err) {
    alert(`Import failed: ${err.message}`);
  }
}

// ── Doc imports ───────────────────────────────────────
async function importDoc(file, ext) {
  const editor = document.getElementById('doc-editor');

  if(ext === 'txt' || ext === 'md') {
    const text = await readAsText(file);
    if(ext === 'md') {
      // Convert markdown to HTML
      editor.innerHTML = marked.parse ? marked.parse(text) : text.replace(/\n/g,'<br>');
    } else {
      editor.innerHTML = text.split('\n').map(l =>
        l.trim() ? `<p>${escapeHtml(l)}</p>` : '<p><br></p>'
      ).join('');
    }
  }
  else if(ext === 'html' || ext === 'htm') {
    const text = await readAsText(file);
    // Extract body content
    const bodyMatch = text.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    editor.innerHTML = bodyMatch ? bodyMatch[1] : text;
  }
  else if(ext === 'docx') {
    // Use mammoth.js if available, else parse XML manually
    if(window.mammoth) {
      const arrayBuffer = await readAsArrayBuffer(file);
      const result = await mammoth.convertToHtml({ arrayBuffer });
      editor.innerHTML = result.value || '<p>Could not parse document content.</p>';
    } else {
      // Fallback: extract raw text from docx ZIP
      const text = await extractDocxText(file);
      editor.innerHTML = text.split('\n').filter(l=>l.trim()).map(l =>
        `<p>${escapeHtml(l)}</p>`
      ).join('');
    }
  }
}

async function extractDocxText(file) {
  // Read docx as ZIP, find word/document.xml, strip XML tags
  try {
    const ab = await readAsArrayBuffer(file);
    const bytes = new Uint8Array(ab);
    // Find "word/document.xml" in ZIP entries
    const decoder = new TextDecoder('utf-8', { fatal: false });
    const raw = decoder.decode(bytes);
    // Quick extraction: find w:t tags content
    const matches = [...raw.matchAll(/<w:t[^>]*>([^<]*)<\/w:t>/g)];
    const lines = [];
    let line = '';
    for(const m of matches) {
      line += m[1];
      if(m[1].endsWith('.') || m[1].endsWith('!') || m[1].endsWith('?')) {
        lines.push(line); line = '';
      }
    }
    if(line) lines.push(line);
    return lines.join('\n') || 'Could not extract document text.';
  } catch(e) { return 'Could not parse .docx file.'; }
}

// ── Sheet imports ─────────────────────────────────────
async function importSheet(file, ext) {
  sheetData = {};

  if(ext === 'csv') {
    const text = await readAsText(file);
    parseCSVIntoSheet(text);
  }
  else if(ext === 'json') {
    const text = await readAsText(file);
    try {
      const json = JSON.parse(text);
      const rows = Array.isArray(json) ? json :
                   Array.isArray(json.data) ? json.data :
                   Object.entries(json).map(([k,v]) => [k, typeof v === 'object' ? JSON.stringify(v) : v]);
      rows.forEach((row, r) => {
        const cols = Array.isArray(row) ? row : Object.values(row);
        cols.forEach((val, c) => {
          const id = cellId(r, c);
          sheetData[id] = { value: String(val ?? ''), display: String(val ?? '') };
        });
      });
    } catch(e) { throw new Error('Invalid JSON format'); }
  }
  else if(ext === 'xlsx' || ext === 'xls') {
    const ab = await readAsArrayBuffer(file);
    const wb = XLSX.read(ab, { type: 'array' });
    const ws = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_array(ws, { defval: '' });
    rows.forEach((row, r) => {
      row.forEach((val, c) => {
        if(val !== '' && val !== null && val !== undefined) {
          const id = cellId(r, c);
          sheetData[id] = { value: String(val), display: String(val) };
        }
      });
    });
  }

  renderSheet();
}

function parseCSVIntoSheet(text) {
  const lines = text.split('\n');
  lines.forEach((line, r) => {
    if(!line.trim()) return;
    // Handle quoted CSV fields
    const cols = [];
    let cur = '', inQuote = false;
    for(let i = 0; i < line.length; i++) {
      const ch = line[i];
      if(ch === '"') { inQuote = !inQuote; }
      else if(ch === ',' && !inQuote) { cols.push(cur.trim()); cur = ''; }
      else cur += ch;
    }
    cols.push(cur.trim());
    cols.forEach((val, c) => {
      const clean = val.replace(/^"|"$/g, '');
      if(clean) {
        const id = cellId(r, c);
        sheetData[id] = { value: clean, display: clean };
      }
    });
  });
  renderSheet();
}

// ── Slide imports ─────────────────────────────────────
async function importSlide(file, ext) {
  if(ext === 'pptx') {
    // Extract slide titles and subtitles from PPTX XML
    try {
      const ab = await readAsArrayBuffer(file);
      const bytes = new Uint8Array(ab);
      const decoder = new TextDecoder('utf-8', { fatal: false });
      const raw = decoder.decode(bytes);

      // Find slide XML blocks (look for <p:sld patterns)
      const slideBlocks = [...raw.matchAll(/<p:sld[\s\S]*?(?=<p:sld|$)/g)];
      slides = [];

      if(slideBlocks.length === 0) {
        // Fallback: create one slide from filename
        slides = [createBlankSlide()];
        slides[0].elements[0].content = currentTitle;
      } else {
        slideBlocks.slice(0, 20).forEach(block => {
          const texts = [...block[0].matchAll(/<a:t>([^<]*)<\/a:t>/g)]
            .map(m => m[1].trim()).filter(Boolean);
          const sl = createBlankSlide();
          if(texts[0]) sl.elements[0].content = texts[0];
          if(texts[1]) sl.elements[1].content = texts.slice(1).join(' ').substring(0, 120);
          slides.push(sl);
        });
      }

      if(!slides.length) slides = [createBlankSlide()];
    } catch(e) {
      slides = [createBlankSlide()];
      slides[0].elements[0].content = currentTitle;
    }
    currentSlide = 0;
    renderSlides();
  }
}

// ── File reading helpers ──────────────────────────────
function readAsText(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result);
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.readAsText(file);
  });
}

function readAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result);
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.readAsArrayBuffer(file);
  });
}

function escapeHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ══════════════════════════════════════════════════════
// PWA SERVICE WORKER REGISTRATION
// ══════════════════════════════════════════════════════
if('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
