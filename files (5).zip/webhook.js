// api/webhook.js — Stripe Webhook Handler
// Listens for payment events and updates user plan in your database

export const config = { api: { bodyParser: false } }; // Required for Stripe signature

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const sig = req.headers['stripe-signature'];

  // Read raw body for signature verification
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const rawBody = Buffer.concat(chunks);

  let event;
  try {
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature failed:', err.message);
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }

  // Handle events
  switch (event.type) {

    case 'checkout.session.completed': {
      const session = event.data.object;
      const email = session.customer_email;
      const plan = session.metadata?.plan;
      console.log(`✅ Payment complete: ${email} → ${plan}`);
      // TODO: Update your Supabase database:
      // await supabase.from('users').update({ plan, is_pro: true }).eq('email', email);
      break;
    }

    case 'customer.subscription.deleted': {
      const sub = event.data.object;
      const email = sub.metadata?.email;
      console.log(`❌ Subscription cancelled: ${email}`);
      // TODO: Downgrade user to free:
      // await supabase.from('users').update({ plan: 'free', is_pro: false }).eq('email', email);
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      const email = invoice.customer_email;
      console.log(`⚠️ Payment failed: ${email}`);
      // TODO: Send dunning email or notify user
      break;
    }

    case 'customer.subscription.updated': {
      const sub = event.data.object;
      const email = sub.metadata?.email;
      const status = sub.status;
      console.log(`🔄 Subscription updated: ${email} → ${status}`);
      break;
    }

    default:
      console.log(`Unhandled event: ${event.type}`);
  }

  res.status(200).json({ received: true });
}
